# DWMS IoThon Hardening v1

This version hardens the prototype for public competition/demo use.

## Changes

- Public device listings no longer expose device API keys.
- Device API keys are generated with `crypto.randomUUID()` instead of predictable timestamps.
- Sensor ingestion is an internal Convex mutation and the HTTP action calls it through the internal API.
- pH/TDS backend alert thresholds are aligned with the DWMS safety engine.
- Device stale/offline handling is aligned to a 30-second policy.
- `flowRate` is now an optional field in the live sensor data model and HTTP ingestion path.
- The hardware bridge forwards live `flowRate` when available.
- Device management no longer displays stored API keys after registration. The key is shown only once from the registration response.
- Hardware mode no longer silently falls back to Demo data after 30 seconds. This prevents simulated data from being mistaken for live measurements during a competition demo.
- Device-page water-status thresholds are aligned with the safety engine.

## Competition truthfulness

The current prototype should describe automated control as prototype decision/control logic unless a physical actuator command path is connected and demonstrated end-to-end.

Live hardware measurements should only be presented as live when the selected device is actually sending them. Demo data should remain explicitly labeled as simulated.
