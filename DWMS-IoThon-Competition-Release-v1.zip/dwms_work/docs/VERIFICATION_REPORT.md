# DWMS Competition Release Verification Report

Date: 2026-09-24

## Verified by source inspection

- One shared threshold module: `shared/dwms-thresholds.ts`.
- Safety engine imports the shared thresholds.
- Convex ingestion imports the same threshold definitions.
- Public device listing strips `apiKey` before returning data.
- Device API-key validation is internal-only and the HTTP ingestion path calls the internal API.
- Registration and rotation use two UUID values for high-entropy secrets.
- Ethm AI checks the authenticated current user and only allows admin/operator roles.
- Hardware mode does not automatically fall back to simulation.
- Emergency state is not cleared when switching data sources.
- Hardware watchdog uses one 10 s warning / 30 s offline policy.
- Flow rate is optional through the sensor schema and ingestion path.
- Missing pH/TDS/turbidity prevents the overall quality state from being reported as safe.
- Thresholds page is presentation-only for safety thresholds, avoiding a localStorage configuration that did not drive the safety engine.
- Audit records are created for device registration, deletion, and API-key rotation.
- Stale decision/alert/report/simulation thresholds were updated to the shared operating model.
- TDS wording no longer claims ordinary filtration removes dissolved salts.
- Competition data-source UI distinguishes simulation from real hardware and hardware-disconnected states.

## Automated checks completed

- Modified TypeScript/TSX files were transpiled with the installed global TypeScript compiler. Result: no syntax/transpile diagnostics in the modified files.
- Static searches were run for previously identified stale thresholds and misleading TDS/filtration claims.

## Checks blocked by environment

- Full dependency install: blocked. Online `npm install` timed out and offline install failed because required packages were not cached.
- Full `tsc -b` / Vite build: blocked by missing project dependencies and generated Convex artifacts.
- ESLint: blocked by missing project dependencies.
- Convex code generation/deployment: not run because the Convex CLI/dependencies are unavailable in this environment.
- Browser runtime regression testing: not run because dependencies/build were unavailable.
- Physical Arduino, flow sensor, actuator, and pump tests: unavailable in this environment.

## Deployment-only verification still required

1. Install dependencies in the project environment.
2. Run Convex code generation.
3. Run `npm run build`.
4. Run `npm run lint`.
5. Deploy to a staging Convex environment.
6. Send real Arduino readings through `/arduino/data`.
7. Verify the dashboard labels the stream as REAL HARDWARE.
8. Verify stale hardware becomes WARNING after 10 s and DISCONNECTED after 30 s.
9. Verify API-key rotation invalidates the old key.
10. Verify the physical actuator path before claiming closed-loop hardware control.
