# DWMS Competition Release Hardening

## Scope
This release hardens the DWMS prototype for IoThon review without claiming capabilities that are not verified on physical hardware.

## Critical
- Shared threshold configuration moved to `shared/dwms-thresholds.ts` and consumed by the safety engine and Convex ingestion rules.
- Missing core sensor data no longer produces a `safe` overall quality state.
- Hardware mode never silently falls back to simulation.
- Emergency state is not cleared merely by switching data sources.
- Ethm AI now requires an authenticated operator or admin account.
- Device API-key validation is internal-only and public device listings never expose the secret.
- API keys are generated with high-entropy UUID material and can be rotated by an admin.

## High
- Backend threshold alerts use the same shared threshold configuration as the UI.
- Offline/watchdog policy is centralized at 10 s warning and 30 s offline.
- `flowRate` remains optional end-to-end. It is never presented as real unless supplied by the hardware payload.
- Audit records are persisted for device registration, deletion, and API-key rotation.
- Competition data-integrity UI explicitly labels `REAL HARDWARE`, `HARDWARE DISCONNECTED`, or `SIMULATION`.
- Scientific wording was corrected so TDS is treated as an operational threshold and filtration is not described as removing dissolved salts.
- Stale pH/TDS/turbidity thresholds in decision, alert, report, and simulation views were aligned with the shared rules.

## Verification
- Source inspection completed after each change group.
- Searches were run for known stale thresholds and misleading TDS/filtration claims.
- Full `npm install` was attempted but timed out in the execution environment before dependencies were available.
- Because dependencies were unavailable, a real `build`, `typecheck`, `lint`, browser runtime test, and Convex deployment test could not be honestly marked as passed.

## Hardware/deployment-only checks
These require the actual project environment or physical device:
- Convex code generation and deployment after schema changes.
- End-to-end Arduino -> HTTP Action -> Convex -> dashboard telemetry.
- Physical flow-rate sensor verification.
- Physical actuator/pump command path and fail-safe behavior.
- Production CORS policy and rate limiting under the deployed domain.
