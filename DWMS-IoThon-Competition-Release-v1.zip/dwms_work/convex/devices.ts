import { query, mutation, internalMutation, internalQuery } from "./_generated/server";
import { v, ConvexError } from "convex/values";
import { internal } from "./_generated/api";
import type { Doc } from "./_generated/dataModel.d.ts";
import type { MutationCtx } from "./_generated/server";
import { createSystemNotification } from "./notifications";
import { THRESHOLDS, OFFLINE_POLICY } from "../shared/dwms-thresholds";

// Helper to require admin
async function requireAdmin(ctx: MutationCtx) {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) throw new ConvexError({ message: "Not authenticated", code: "UNAUTHENTICATED" });
  const user = await ctx.db.query("users").withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier)).unique();
  if (!user || user.role !== "admin") throw new ConvexError({ message: "Admin access required", code: "FORBIDDEN" });
  return user;
}

// List all registered devices (public read — guests can view)
export const listDevices = query({
  args: {},
  handler: async (ctx) => {
    // Public device metadata is safe for the monitoring dashboard.
    // Never expose the device authentication secret through a public query.
    const devices = await ctx.db.query("devices").collect();
    return devices.map(({ apiKey: _apiKey, ...device }) => device);
  },
});

// Register a new Arduino device (admin only)
export const registerDevice = mutation({
  args: {
    deviceId: v.string(),
    name: v.string(),
    location: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const admin = await requireAdmin(ctx);
    // Check for duplicate
    const existing = await ctx.db.query("devices").withIndex("by_deviceId", (q) => q.eq("deviceId", args.deviceId)).unique();
    if (existing) throw new ConvexError({ message: "Device ID already registered", code: "CONFLICT" });

    // Generate a high-entropy device API key
    const apiKey = `ldwms_${crypto.randomUUID().replaceAll("-", "")}${crypto.randomUUID().replaceAll("-", "")}`;
    await ctx.db.insert("devices", {
      deviceId: args.deviceId,
      name: args.name,
      location: args.location,
      apiKey,
      status: "offline",
    });
    await ctx.db.insert("auditLog", { actorUserId: admin._id, action: "device.registered", entityType: "device", entityId: args.deviceId, details: "Device registered.", createdAt: new Date().toISOString() });
    return { apiKey };
  },
});

// Rotate a device API key (admin only). The new key is returned once.
export const rotateDeviceKey = mutation({
  args: { deviceId: v.string() },
  handler: async (ctx, args) => {
    const admin = await requireAdmin(ctx);
    const device = await ctx.db.query("devices").withIndex("by_deviceId", (q) => q.eq("deviceId", args.deviceId)).unique();
    if (!device) throw new ConvexError({ message: "Device not found", code: "NOT_FOUND" });
    const apiKey = `ldwms_${crypto.randomUUID().replaceAll("-", "")}${crypto.randomUUID().replaceAll("-", "")}`;
    await ctx.db.patch(device._id, { apiKey });
    await ctx.db.insert("auditLog", { actorUserId: admin._id, action: "device.api_key_rotated", entityType: "device", entityId: device.deviceId, details: "Device API key rotated; secret returned only in this mutation response.", createdAt: new Date().toISOString() });
    return { apiKey };
  },
});

// Delete a device (admin only)
export const deleteDevice = mutation({
  args: { deviceId: v.string() },
  handler: async (ctx, args) => {
    const admin = await requireAdmin(ctx);
    const device = await ctx.db.query("devices").withIndex("by_deviceId", (q) => q.eq("deviceId", args.deviceId)).unique();
    if (!device) throw new ConvexError({ message: "Device not found", code: "NOT_FOUND" });
    await ctx.db.delete(device._id);
    await ctx.db.insert("auditLog", { actorUserId: admin._id, action: "device.deleted", entityType: "device", entityId: device.deviceId, details: "Device deleted.", createdAt: new Date().toISOString() });
  },
});

// Get latest sensor reading for a device (public)
export const getLatestReading = query({
  args: { deviceId: v.string() },
  handler: async (ctx, args): Promise<Doc<"sensorReadings"> | null> => {
    return await ctx.db
      .query("sensorReadings")
      .withIndex("by_deviceId_timestamp", (q) => q.eq("deviceId", args.deviceId))
      .order("desc")
      .first();
  },
});

// Get recent readings for a device (public)
export const getRecentReadings = query({
  args: { deviceId: v.string(), limit: v.optional(v.number()) },
  handler: async (ctx, args): Promise<Doc<"sensorReadings">[]> => {
    return await ctx.db
      .query("sensorReadings")
      .withIndex("by_deviceId_timestamp", (q) => q.eq("deviceId", args.deviceId))
      .order("desc")
      .take(args.limit ?? 50);
  },
});

// Internal: save a sensor reading (called from HTTP action)
export const internalSaveReading = internalMutation({
  args: {
    deviceId: v.string(),
    ph: v.number(),
    tds: v.number(),
    turbidity: v.number(),
    flowRate: v.optional(v.number()),
  },
  handler: async (ctx, args): Promise<void> => {
    const now = new Date().toISOString();

    // Update device lastSeen + status to online
    const device = await ctx.db.query("devices").withIndex("by_deviceId", (q) => q.eq("deviceId", args.deviceId)).unique();
    if (device) {
      await ctx.db.patch(device._id, { lastSeen: now, status: "online" });
    }

    // Insert reading
    await ctx.db.insert("sensorReadings", {
      deviceId: args.deviceId,
      timestamp: now,
      ph: args.ph,
      tds: args.tds,
      turbidity: args.turbidity,
      ...(args.flowRate !== undefined ? { flowRate: args.flowRate } : {}),
    });

    // Schedule offline check in 30 seconds
    await ctx.scheduler.runAfter(OFFLINE_POLICY.offlineAfterMs, internal.devices.checkDeviceStale, {
      deviceId: args.deviceId,
      expectedLastSeen: now,
    });

    // Threshold alert logic — uses the shared safety thresholds.
    const alerts: Array<{ level: "critical" | "warning"; title: string; message: string; parameter: string; value: string }> = [];
    if (args.ph < THRESHOLDS.ph.safe.min || args.ph > THRESHOLDS.ph.safe.max) {
      const level = args.ph < THRESHOLDS.ph.critical.below || args.ph > THRESHOLDS.ph.critical.above ? "critical" : "warning";
      alerts.push({ level, title: `pH ${level === "critical" ? "CRITICAL" : "Warning"}: ${args.ph.toFixed(2)}`, message: `pH ${args.ph.toFixed(2)} is outside the configured operating range (${THRESHOLDS.ph.safe.min}–${THRESHOLDS.ph.safe.max}). Device: ${args.deviceId}`, parameter: "pH", value: args.ph.toFixed(2) });
    }
    if (args.tds >= THRESHOLDS.tds.safe.max) {
      const level = args.tds > THRESHOLDS.tds.critical.above ? "critical" : "warning";
      alerts.push({ level, title: `TDS ${level === "critical" ? "CRITICAL" : "Warning"}: ${args.tds.toFixed(0)} ppm`, message: `TDS ${args.tds.toFixed(0)} ppm exceeds the configured operating threshold of ${THRESHOLDS.tds.safe.max} ppm. Device: ${args.deviceId}`, parameter: "TDS", value: `${args.tds.toFixed(0)} ppm` });
    }
    if (args.turbidity >= THRESHOLDS.turbidity.safe.max) {
      const level = args.turbidity > THRESHOLDS.turbidity.critical.above ? "critical" : "warning";
      alerts.push({ level, title: `Turbidity ${level === "critical" ? "CRITICAL" : "Warning"}: ${args.turbidity.toFixed(1)} NTU`, message: `Turbidity ${args.turbidity.toFixed(1)} NTU exceeds the configured operating threshold of ${THRESHOLDS.turbidity.safe.max} NTU. Device: ${args.deviceId}`, parameter: "Turbidity", value: `${args.turbidity.toFixed(1)} NTU` });
    }

    // Broadcast alerts to all admin/operator users
    if (alerts.length > 0) {
      const users = await ctx.db.query("users").collect();
      const targets = users.filter((u) => u.role === "admin" || u.role === "operator");
      for (const alert of alerts) {
        for (const target of targets) {
          await createSystemNotification(ctx, target._id, {
            level: alert.level,
            category: "threshold",
            title: alert.title,
            message: alert.message,
            parameter: alert.parameter,
            value: alert.value,
          });
        }
      }
    }
  },
});

// Scheduled: check if a device has gone stale (no new data in 30s)
export const checkDeviceStale = internalMutation({
  args: {
    deviceId: v.string(),
    expectedLastSeen: v.string(),
  },
  handler: async (ctx, args): Promise<void> => {
    const device = await ctx.db
      .query("devices")
      .withIndex("by_deviceId", (q) => q.eq("deviceId", args.deviceId))
      .unique();
    if (!device) return;

    // If lastSeen hasn't changed since we scheduled this check, mark offline
    if (device.lastSeen === args.expectedLastSeen && device.status === "online") {
      await ctx.db.patch(device._id, { status: "offline" });

      // Notify admin/operator users
      const users = await ctx.db.query("users").collect();
      const targets = users.filter((u) => u.role === "admin" || u.role === "operator");
      for (const target of targets) {
        await createSystemNotification(ctx, target._id, {
          level: "warning",
          category: "device",
          title: `Device offline: ${device.name}`,
          message: `Device ${device.deviceId} (${device.name}) has not sent data for 30+ seconds. Last seen: ${device.lastSeen ?? "unknown"}`,
        });
      }
    }
  },
});

// Internal: validate API key and return device
export const validateApiKey = internalQuery({
  args: { apiKey: v.string() },
  handler: async (ctx, args): Promise<Doc<"devices"> | null> => {
    return await ctx.db.query("devices").withIndex("by_apiKey", (q) => q.eq("apiKey", args.apiKey)).unique();
  },
});
