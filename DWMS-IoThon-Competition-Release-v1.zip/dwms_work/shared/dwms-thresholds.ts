export const MAX_FILTER_CAPACITY = 2.0;

export const THRESHOLDS = {
  ph: { safe: { min: 6.5, max: 8.5 }, critical: { below: 5.5, above: 10.0 }, unit: "", label: "pH" },
  tds: { safe: { max: 500 }, warning: { min: 500, max: 1500 }, critical: { above: 1500 }, unit: "ppm", label: "TDS" },
  turbidity: { safe: { max: 5 }, warning: { min: 5, max: 50 }, critical: { above: 50 }, unit: "NTU", label: "Turbidity" },
  flowRate: { safe: { min: 0.5, max: 2.0 }, warning: { min: 2.0, max: 3.0 }, critical: { above: 3.0 }, unit: "L/min", label: "Flow Rate" },
} as const;

export const OFFLINE_POLICY = { warningAfterMs: 10_000, offlineAfterMs: 30_000 } as const;
